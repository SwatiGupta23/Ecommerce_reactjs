import React from 'react'

function Singleproduct() {
  return (
    <div>
      <h1>Singleproduct</h1>
    </div>
  )
}

export default Singleproduct
