import React from 'react';
import Hero from '../Component/Hero/Hero';
import Offers from '../Component/Offers/Offers';
import Popular from '../Component/Popular/Popular';
import NewCollections from '../Component/NewCollections/NewCollections';
import NewLetter from '../Component/NewsLetter/NewLetter';
const Home = () => {
  return (
         <div>
          <Hero/>
          <Popular/>
          <Offers/>
          <NewCollections/>
          <NewLetter/>
         </div>
  )
}
   
export default Home;
