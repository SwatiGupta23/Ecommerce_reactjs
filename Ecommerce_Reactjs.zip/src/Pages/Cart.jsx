import React from 'react'

const Cart = () => {
  return (
    <div>
      cart
    </div>
  )
}

export default Cart
