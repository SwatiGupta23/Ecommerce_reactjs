import React from 'react'

const LoginSignup = () => {
  return (
    <div>
      login
    </div>
  )
}

export default LoginSignup
