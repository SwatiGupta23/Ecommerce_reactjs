import React from 'react'
import Shop from '../Component/Shop/Shop'
import product_banner from '../Component/Assets/product_banner3.jpg'
const Products = () => {
  return (
    <div>
      <img src={product_banner} className='img' alt='banner' style={{width:"100%"}} />
      <Shop/>
    </div>
  )
}

export default Products
