import React from 'react'
import './NewsLetter.css'


const NewLetter = () => {
  return (
    <div className='NewsLatter' >
      <h1>Get EXClusive Offers on Your Email </h1>
      <p>Subscriber to our newletter and stay updated</p>
      <div>
        <input type='email' placeholder='your email id'/>
        <button>Subscribe</button>
      </div>
    </div>
  )
}

export default NewLetter
