// import Container from 'react-bootstrap/Container';
// import Nav from 'react-bootstrap/Nav';
// import Navbar from 'react-bootstrap/Navbar';
import { Link } from 'react-router-dom';
import logo from '../Assets/logo.png';
import cart_icon from '../Assets/cart_icon.png'; 
import './Nav.css';
// import { useState } from 'react';

const Header = () => {
  // const [menu,setMenu] = useState("shop");
  return (
    // <Navbar expand="lg" className="bg-body-tertiary">
    //   <Container>
    //     <Navbar.Brand href="/">
    //     <img src={logo}  alt='logo'/>
  
    //     </Navbar.Brand>
    //     <Navbar.Toggle aria-controls="basic-navbar-nav" />
    //     <Navbar.Collapse id="basic-navbar-nav" >
    //       <Nav className="me-auto justify-content-end">
    //         <NavLink className="nav-link" to="/">Home</NavLink>
    //         <NavLink className="nav-link" to="/about">About</NavLink>
    //         <NavLink className="nav-link" to="/contact">Contact</NavLink>
    //         <NavLink className="nav-link" to="/product">Product</NavLink>
    //         <NavLink className="nav-link" to="/cart">Cart</NavLink>
    //       </Nav>
    //       <div className='nav-login-cart'>
    //       <Link to='/login'><button className='btn' style={{backgroundColor: "rgb(40, 140, 229)",color:'#fff', margin:"10px", padding:"10px"}}>Login</button></Link>
    //       <img src={cart_icon} alt='cart-icon' />
    //      <Link to='cart'> <div className='nav-cart-count'>0 </div></Link>
    //       </div>
    //     </Navbar.Collapse>
    //   </Container>
    // </Navbar>
<div className='navbar'>
  <div className='nav-logo'>
   <img src={logo} alt='logo'/>
   <p>SHOPPER</p>
  </div>
  <ul className='nav-menu'>

    {/* <li onClick={()=>{setMenu('shop')}}><Link to="/">shop</Link>{menu==="shop"?<hr/>:<></>}</li>
    <li onClick={()=>{setMenu('mens')}}><Link to="/mens">mens</Link>{menu==="mens"?<hr/>:<></>}</li>
    <li onClick={()=>{setMenu('womens')}}><Link to="/womens">womens</Link>{menu==="womens"?<hr/>:<></>}</li>
    <li onClick={()=>{setMenu('kids')}}><Link to="/kids">kids</Link>{menu==="kids"?<hr/>:<></>}</li> */}

  <Link to='/'><li>Home</li></Link> 
  <Link to="/about"><li>About</li></Link>
    <Link to="/contact" ><li>Contact</li></Link>
    <Link to="/Product" ><li>Product</li></Link>
    <Link to="/singleproduct" ><li>Shop</li></Link>
  </ul>
  <div className='nav-login-cart'>
       <Link to='/login'><button className='btn'>Login</button></Link>
       <Link to='cart'><img src={cart_icon} alt='cart-icon' /></Link>
       <div className='nav-cart-count'>0 </div>
       </div>

</div>
  )
}

export default Header;