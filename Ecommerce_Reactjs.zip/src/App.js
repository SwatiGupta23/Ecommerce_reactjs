import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./Pages/Home";
import Error from './Component/Error';
import Header from './Component/Navbar/Header';
import Footer from './Component/Footer/Footer';
import Products from './Pages/Products';
import Contact from './Pages/Contact';
import Cart from './Pages/Cart';
import LoginSignup from './Pages/LoginSignup';
import About from './Pages/About';

const App =() => {
 

  return (
    <div className="App">
      <BrowserRouter>
      <Header/>
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path='/about' element={<About/>}/>   
          <Route path=':productId' element={<Products/>} />
          <Route path='/contact' element={<Contact/>} />
          <Route path='/cart' element={<Cart/>}/>
          <Route path='/login' element={<LoginSignup/>}/>
          <Route path="*" element={<Error/>}  />
        </Routes>
        <Footer/>
      </BrowserRouter>
      {/* </ThemeProvider> */}
    </div>
  );
}

export default App;
